# CalebSec — Suricata, Zeek and SOAR integration pack

**Designed for:** https://github.com/CalebSecurity1998/CalebSec, `main`, application folder `calebsec_siem_pro/` (inspected 2026-11-02).

This pack adds a real ingestion/API/UI integration to the **existing** FastAPI SIEM, not a separate replacement server. It does **not** install Suricata or Zeek sensors; those tools must run where network traffic is visible and send their JSON output to CalebSec.

## Install (recommended)

1. Back up your CalebSec checkout and SQLite DB. Extract ZIP anywhere locally.
2. From the extracted package directory run: `python install.py --repo /path/to/CalebSec`
3. Review the diff before committing (do not commit the `*.bak` local backup): `git -C /path/to/CalebSec diff` and `git -C /path/to/CalebSec status`.
4. Configure an unpredictable ingestion token; on macOS/Linux: `export CALEBSEC_SENSOR_TOKEN="$(python -c 'import secrets; print(secrets.token_urlsafe(36))')"`. Keep it outside Git. Configure `ADMIN_PASSWORD`, `SESSION_SECRET` and HTTPS as appropriate.
5. Start your existing app as usual, for example: `cd /path/to/CalebSec/calebsec_siem_pro && python -m uvicorn main:app --reload`.
6. Log in as the CalebSec admin and open `http://127.0.0.1:8000/network-ops`.

The installer copies only new files into `calebsec_siem_pro/network_ops/` and appends a **small router registration** to the existing `calebsec_siem_pro/main.py`, leaving all original routes in place. It creates a backup of `main.py` when applying the hook; it is safe to re-run. If you want to avoid the installer, copy the entire `calebsec_siem_pro/network_ops` directory into your repository and append the following to the *end* of your existing `calebsec_siem_pro/main.py`:

```python
# CalebSec network sensor and SOAR extension
from network_ops.api import build_router as _build_network_ops_router
app.include_router(_build_network_ops_router(require_admin_session, validate_csrf_token, get_csrf_token))
```

Do not upload the unextracted ZIP and expect GitHub/Render to execute it. Commit extracted files, including the modified `main.py`, to GitHub. GitHub's Upload Files screen may upload nested files; using Git locally is generally easiest.

## JSONL sensor ingestion

Two authenticated endpoints accept individual JSON objects, JSON arrays or newline-delimited JSON up to 2 MiB and 1,000 records per request:

- `POST /api/network-ops/ingest/suricata`
- `POST /api/network-ops/ingest/zeek`

Supply `Authorization: Bearer <CALEBSEC_SENSOR_TOKEN>` (or `X-Sensor-Token`); configure the same token on the collector side. **Example:**

```bash
curl -X POST http://127.0.0.1:8000/api/network-ops/ingest/suricata \
  -H "Authorization: Bearer $CALEBSEC_SENSOR_TOKEN" \
  -H "Content-Type: application/x-ndjson" \
  --data-binary @examples/suricata-eve.jsonl
curl -X POST http://127.0.0.1:8000/api/network-ops/ingest/zeek \
  -H "Authorization: Bearer $CALEBSEC_SENSOR_TOKEN" \
  --data-binary @examples/zeek-conn.jsonl
```

For Zeek: configure `@load policy/tuning/json-logs` or `redef LogAscii::use_json = T;` in your Zeek deployment, then ship JSON `conn.log`, `dns.log`, `http.log`, `ssl.log`, etc., **separately tagged** using header `X-Zeek-Log-Type: dns` when the log type cannot be inferred from a record. Do not ship arbitrary Zeek TSV lines.

For production-scale sensors use a managed log shipper (e.g. Filebeat, Vector, Fluent Bit) configured to POST bounded batches over TLS; or adapt `scripts/ship_jsonl.py` as a basic local polling collector. The example script is a development tool, not a durable enterprise shipper; it uses a state file and cannot guarantee exactly-once delivery after crashes. Only ship authorized telemetry.

## What is included

- Suricata EVE `alert`, `dns`, `http`, `tls`, and flow event ingestion; Suricata signature/severity -> existing CalebSec alerts.
- Zeek JSON `conn`, `dns`, `http`, `ssl`, `notice`, and other log types; searchable network event history.
- Normalization into existing CalebSec `logs` and structured `network_sensor_events` table. Event identity, `community_id`, flow tuple, domain, metadata and original JSON retained.
- Cross-source correlation in the network UI by `community_id` (preferred) or 5-tuple / reverse-direction 4-tuple + timestamp proximity (best-effort).
- SQLite-backed SOAR playbook runs with steps, statuses, an audit trail, no duplicate per-event execution, and auto-case creation for high/critical Suricata alerts. Reputational enrichment is **local IOC-list based**, no external API call or data egress.
- Optional manual replay of a playbook using authenticated admin + CSRF; `dry_run=true` offers preview without case creation.
- **No external firewall or endpoint action is executed.** Any proposed IP block is review-only, requiring a separately engineered provider integration and approvals.

## Configuration

| Env variable | Default | Purpose |
|---|---|---|
| `CALEBSEC_SENSOR_TOKEN` | unset (ingest disabled) | Required secret for sensor ingestion |
| `CALEBSEC_AUTO_SOAR` | `true` | Auto-run safe triage on high/critical Suricata alerts |
| `CALEBSEC_NETWORK_MAX_AGE_MINUTES` | `10` | Cross-source correlation time window |

The existing app's admin session is required for the browser UI, event listing, and SOAR endpoints. Sensor token is accepted **only** on the ingestion API. The app's existing CSRF validation is reused for interactive SOAR actions. Protect the deployment with TLS; never expose demo passwords. Network telemetry can contain sensitive metadata; review retention and access policies.

## Run tests

From package root: `python -m unittest discover -s tests -v` (Python 3.10+). Application requires existing repo dependencies (`pip install -r calebsec_siem_pro/requirements.txt`).

## Important limits

- Works with current CalebSec `database.py` schema and uses its `insert_log`, `insert_alert`, `create_case`, and `log_audit_event` helpers. The core `siem.db` remains unchanged except for the two new tables.
- Existing alerts are deduplicated by CalebSec across rule/src_ip/description. A SOAR case is created once per **unique ingested Suricata event** when a matching alert exists and when no case already references that alert.
- Sensors must be configured to supply events. GitHub/Render deployment alone cannot sniff traffic.
- Existing app's global exception handler can redirect unauthorized HTML requests; JSON API errors are returned directly where possible.
- The existing app includes its own deployment/security assumptions; this pack is for portfolio and lab use and has not undergone production penetration testing.
