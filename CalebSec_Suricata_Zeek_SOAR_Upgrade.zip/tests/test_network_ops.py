"""Unit tests against isolated sqlite schema; no sensor installation required."""
import json
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]/'calebsec_siem_pro'
sys.path.insert(0,str(ROOT))
# Import module independent of the real app's DB, using a minimal test database module.
import sqlite3
stub=types.ModuleType('database')
DB=None

def connect():
    return sqlite3.connect(DB)

def insert_log(value):
    with connect() as c:
        c.execute('INSERT INTO logs(timestamp,event_type,src_ip,message) VALUES(?,?,?,?)',
            (value['timestamp'],value['event_type'],value['src_ip'],value['message']))

def insert_alert(value):
    with connect() as c:
        c.execute('INSERT OR IGNORE INTO alerts(rule,severity,src_ip,description,mitre) VALUES(?,?,?,?,?)',
            (value['rule'],value['severity'],value['src_ip'],value['description'],value['mitre']))

def create_case(alert_id,title,notes):
    with connect() as c:
        c.execute('INSERT INTO cases(alert_id,title,notes) VALUES(?,?,?)',(alert_id,title,notes))

def log_audit_event(*args):
    pass

stub.connect=connect
stub.insert_log=insert_log
stub.insert_alert=insert_alert
stub.create_case=create_case
stub.log_audit_event=log_audit_event
sys.modules['database']=stub
from network_ops.normalize import normalize, suricata_alert
from network_ops import store,soar
from network_ops.api import ingest_records

class TestNetworkOps(unittest.TestCase):
    def setUp(self):
        global DB
        self.temp=tempfile.TemporaryDirectory()
        DB=str(Path(self.temp.name)/'isolated.db')
        with connect() as c:
            c.execute('CREATE TABLE logs(id INTEGER PRIMARY KEY,timestamp TEXT,event_type TEXT,src_ip TEXT,message TEXT)')
            c.execute('CREATE TABLE alerts(id INTEGER PRIMARY KEY,rule TEXT,severity TEXT,src_ip TEXT,description TEXT,mitre TEXT,UNIQUE(rule,src_ip,description))')
            c.execute('CREATE TABLE cases(id INTEGER PRIMARY KEY,alert_id INTEGER,title TEXT,notes TEXT)')
        store.init_tables()
    def tearDown(self):
        self.temp.cleanup()
    def test_suricata_alert_and_idempotent_soar(self):
        item={'timestamp':'2026-11-02T20:00:00+00:00','event_type':'alert','src_ip':'203.0.113.1',
              'dest_ip':'198.51.100.2','alert':{'severity':2,'signature_id':42,'signature':'Demo alert'}}
        with patch.dict('os.environ',{'CALEBSEC_AUTO_SOAR':'true'}):
            first=ingest_records('suricata',[item])
            second=ingest_records('suricata',[item])
        self.assertEqual(first['accepted'],1)
        self.assertEqual(first['soar_runs'],1)
        self.assertEqual(second['duplicates'],1)
        self.assertEqual(len(store.list_runs()),1)
        with connect() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM cases').fetchone()[0],1)
            self.assertEqual(c.execute('SELECT COUNT(*) FROM logs').fetchone()[0],1)
    def test_zeek_correlation(self):
        sur={'timestamp':'2026-11-02T20:00:00+00:00','event_type':'flow',
             'src_ip':'192.0.2.1','dest_ip':'198.51.100.2','community_id':'1:abc'}
        zeek={'ts':1793650000,'_path':'conn','id.orig_h':'192.0.2.1','id.resp_h':'198.51.100.2','community_id':'1:abc'}
        # Explicitly synchronize timestamp for correlation.
        zeek['ts']=1793650000
        sur['timestamp']=__import__('datetime').datetime.fromtimestamp(zeek['ts'],__import__('datetime').timezone.utc).isoformat()
        ingest_records('suricata',[sur])
        ingest_records('zeek',[zeek])
        event=store.list_events(source='suricata')[0]
        related=store.related_events(event['id'])
        self.assertEqual(len(related),1)
        self.assertEqual(related[0]['source'],'zeek')
    def test_dry_run_does_not_create_case(self):
        item={'event_type':'alert','src_ip':'192.0.2.1','dest_ip':'192.0.2.2',
              'alert':{'severity':1,'signature_id':10,'signature':'Test'}}
        with patch.dict('os.environ',{'CALEBSEC_AUTO_SOAR':'false'}):
            ingest_records('suricata',[item])
        event=store.list_events()[0]
        result=soar.run(event['id'],dry_run=True)
        self.assertEqual(result['status'],'preview')
        with connect() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM cases').fetchone()[0],0)

if __name__=='__main__': unittest.main()
