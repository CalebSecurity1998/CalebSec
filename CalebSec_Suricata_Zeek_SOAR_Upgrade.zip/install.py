#!/usr/bin/env python3
"""Non-destructive install into an existing CalebSec repository checkout."""
import argparse
from pathlib import Path
import shutil
import sys

HOOK="""\n\n# BEGIN CALEBSEC NETWORK_OPS UPGRADE\nfrom network_ops.api import build_router as _build_network_ops_router\napp.include_router(_build_network_ops_router(require_admin_session, validate_csrf_token, get_csrf_token))\n# END CALEBSEC NETWORK_OPS UPGRADE\n"""

def install(repo):
    repo=Path(repo).expanduser().resolve()
    application=repo/'calebsec_siem_pro'
    main=application/'main.py'
    if not main.is_file() or not (application/'database.py').is_file():
        raise RuntimeError('Expected CalebSec repo with calebsec_siem_pro/main.py and database.py')
    original=main.read_text(encoding='utf-8')
    if 'def require_admin_session(' not in original or 'def validate_csrf_token(' not in original or 'def get_csrf_token(' not in original:
        raise RuntimeError('Expected admin and CSRF hooks not found; no changes made')
    source=Path(__file__).parent/'calebsec_siem_pro'/'network_ops'
    dest=application/'network_ops'
    if dest.exists():
        existing=[p.name for p in dest.iterdir() if p.is_file()]
        if existing:
            raise RuntimeError('network_ops already exists; refusing to overwrite files. Re-run only after manual review.')
    if 'BEGIN CALEBSEC NETWORK_OPS UPGRADE' in original:
        print('Existing router hook detected; no modification to main.py.')
    else:
        backup=main.with_suffix('.py.before-network-ops.bak')
        if backup.exists():
            raise RuntimeError('Backup filename already exists; refusing to overwrite')
        shutil.copy2(main,backup)
        main.write_text(original.rstrip()+HOOK,encoding='utf-8')
        print('Backed up main.py to', backup)
    shutil.copytree(source,dest,dirs_exist_ok=True)
    print('Installed module:',dest)
    print('Review changes with: git -C',repo,'diff')
    print('Set CALEBSEC_SENSOR_TOKEN before enabling sensor ingestion.')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',required=True,help='Path to existing CalebSec checkout')
    args=parser.parse_args()
    try:
        install(args.repo)
    except Exception as exc:
        print(f'Install failed: {exc}',file=sys.stderr)
        raise SystemExit(1)
