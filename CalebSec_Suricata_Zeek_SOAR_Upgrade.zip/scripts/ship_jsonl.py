#!/usr/bin/env python3
"""Lab-only incremental JSONL shipper; not a production log transport."""
import argparse
import json
import os
from pathlib import Path
from urllib.request import Request,urlopen


def ship(path,endpoint,token,state):
    path=Path(path)
    state=Path(state)
    offset=int(state.read_text()) if state.exists() else 0
    if offset>path.stat().st_size: offset=0
    with path.open('rb') as f:
        f.seek(offset)
        # Only send complete newline-terminated records.
        records=[]
        end=offset
        while len(records)<500:
            line=f.readline()
            if not line or not line.endswith(b'\n'): break
            json.loads(line)
            records.append(line)
            end=f.tell()
    if not records:
        print('No new complete records')
        return
    request=Request(endpoint,data=b''.join(records),headers={
        'Authorization':'Bearer '+token,'Content-Type':'application/x-ndjson'},method='POST')
    with urlopen(request,timeout=15) as resp:
        print(resp.read().decode())
    state.write_text(str(end))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--file',required=True)
    p.add_argument('--source',choices=['zeek','suricata'],required=True)
    p.add_argument('--url',default='http://127.0.0.1:8000')
    p.add_argument('--state')
    args=p.parse_args()
    key=os.environ.get('CALEBSEC_SENSOR_TOKEN')
    if not key: p.error('CALEBSEC_SENSOR_TOKEN is required')
    ship(args.file,args.url.rstrip('/')+'/api/network-ops/ingest/'+args.source,key,
         args.state or args.file+'.calebsec.offset')
