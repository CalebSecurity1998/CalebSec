"""Drop-in routes integrated with CalebSec's existing session and CSRF helpers."""
from __future__ import annotations
import json
import os
import secrets
from html import escape
from urllib.parse import quote
from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
import database
from . import store, soar
from .normalize import normalize, suricata_alert

MAX_BODY=2*1024*1024
MAX_EVENTS=1000


def _parse_payload(payload):
    raw=payload.decode("utf-8")
    try:
        obj=json.loads(raw)
        parsed=obj if isinstance(obj,list) else [obj]
    except json.JSONDecodeError:
        parsed=[json.loads(line) for line in raw.splitlines() if line.strip()]
    if len(parsed)>MAX_EVENTS:
        raise ValueError(f"Maximum {MAX_EVENTS} records")
    if not parsed or any(not isinstance(x,dict) for x in parsed):
        raise ValueError("Must supply JSON objects")
    return parsed


def ingest_records(source, records, zeek_log_type=None):
    """Synchronous API for direct tests and integrations."""
    normalized=[normalize(source,r,zeek_log_type) for r in records]
    accepted=0
    duplicates=0
    alerts=0
    playbooks=0
    for r in normalized:
        event_id, created=store.insert_event(r)
        if not created:
            duplicates+=1
            continue
        accepted+=1
        database.insert_log(r)
        alert=suricata_alert(r)
        if alert:
            database.insert_alert(alert)
            alerts+=1
            if alert["severity"] in ("High","Critical") and os.getenv("CALEBSEC_AUTO_SOAR","true").lower()=="true":
                soar.run(event_id,actor="sensor_ingest")
                playbooks+=1
    if accepted:
        database.log_audit_event("sensor_ingest",f"{source}_batch",f"accepted={accepted}, duplicates={duplicates}, alerts={alerts}, playbooks={playbooks}")
    return {"source":source,"accepted":accepted,"duplicates":duplicates,"alerts":alerts,"soar_runs":playbooks}


def build_router(require_admin_session,validate_csrf_token,get_csrf_token):
    router=APIRouter()

    def admin(request):
        return require_admin_session(request)

    @router.post("/api/network-ops/ingest/{source}")
    async def ingest(source: str,request:Request):
        if source not in ("suricata","zeek"):
            raise HTTPException(status_code=404,detail="Unknown sensor")
        token=os.getenv("CALEBSEC_SENSOR_TOKEN","")
        supplied=request.headers.get("authorization","")
        if supplied.lower().startswith("bearer "):
            supplied=supplied[7:].strip()
        else:
            supplied=request.headers.get("x-sensor-token","")
        if not token or not supplied or not secrets.compare_digest(token,supplied):
            raise HTTPException(status_code=401,detail="Valid sensor token required")
        # Important: read at most limit + 1 bytes to reject large bodies.
        chunks=[]
        size=0
        async for chunk in request.stream():
            size+=len(chunk)
            if size>MAX_BODY:
                raise HTTPException(status_code=413,detail="Payload exceeds 2 MiB")
            chunks.append(chunk)
        try:
            records=_parse_payload(b"".join(chunks))
            log_type=request.headers.get("x-zeek-log-type")
            return ingest_records(source,records,log_type)
        except (UnicodeDecodeError,ValueError,TypeError,KeyError) as exc:
            raise HTTPException(status_code=400,detail=str(exc)) from exc

    @router.get("/api/network-ops/events")
    async def events(request:Request,source:str="",limit:int=100):
        admin(request)
        return {"events":[{k:v for k,v in item.items() if k!="raw_json"} for item in store.list_events(min(max(1,limit),500),source)]}

    @router.get("/api/network-ops/correlate/{event_id}")
    async def correlate(event_id:int,request:Request):
        admin(request)
        if not store.get_event(event_id):
            raise HTTPException(status_code=404,detail="Event not found")
        try:
            minutes=max(1,min(int(os.getenv("CALEBSEC_NETWORK_MAX_AGE_MINUTES","10")),120))
        except ValueError:
            minutes=10
        return {"event_id":event_id,"related":store.related_events(event_id,minutes)}

    @router.get("/api/network-ops/soar/runs")
    async def runs(request:Request):
        admin(request)
        return {"runs":store.list_runs(100)}

    @router.post("/api/network-ops/soar/run/{event_id}")
    async def execute(event_id:int,request:Request):
        actor=admin(request)
        form=await request.form()
        validate_csrf_token(request,form.get("csrf_token"))
        dry_run=str(form.get("dry_run","false")).lower()=="true"
        try:
            result=soar.run(event_id,dry_run=dry_run,actor=actor)
        except ValueError as exc:
            raise HTTPException(status_code=400,detail=str(exc)) from exc
        if "text/html" in request.headers.get("accept",""):
            return RedirectResponse("/network-ops?notice="+quote(result["status"]),status_code=303)
        return result

    @router.get("/network-ops",response_class=HTMLResponse)
    async def dashboard(request:Request,source:str="",notice:str=""):
        admin(request)
        token=get_csrf_token(request)
        events=store.list_events(100,source)
        runs=store.list_runs(25)
        rows=[]
        for e in events:
            safe=lambda val:escape(str(val or ""))
            action=""
            if e["source"]=="suricata" and e["category"]=="alert":
                action=(f'<form method="post" action="/api/network-ops/soar/run/{e["id"]}">'
                    f'<input type="hidden" name="csrf_token" value="{safe(token)}">'
                    '<button type="submit" name="dry_run" value="true">Preview SOAR</button>'
                    '<button type="submit" name="dry_run" value="false">Run triage</button></form>')
            rows.append('<tr>'+''.join(f'<td>{safe(x)}</td>' for x in [e["id"],e["source"],e["category"],e["timestamp"],e["src_ip"],e["dest_ip"],e["message"]]) +f'<td><a href="/api/network-ops/correlate/{e["id"]}">Related JSON</a> {action}</td></tr>')
        runrows=''.join('<tr><td>'+escape(str(r["created_at"]))+'</td><td>'+escape(r["playbook"])+"</td><td>"+escape(r["status"])+"</td><td>"+escape(str(r["event_id"]))+'</td></tr>' for r in runs)
        return HTMLResponse("""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>CalebSec Network & SOAR</title><style>
        body{font:15px system-ui,Arial;background:#0b1220;color:#e2e8f0;margin:0;padding:30px}main{max-width:1320px;margin:auto}a{color:#70caff}nav a{margin-right:16px}h1{font-size:26px}p{color:#adc0d5}table{width:100%;border-collapse:collapse;font-size:13px}td,th{border-bottom:1px solid #2e405c;text-align:left;padding:9px;vertical-align:top}th{color:#a8c3e4}section{background:#152238;border:1px solid #2e405c;border-radius:12px;padding:18px;margin:20px 0;overflow-x:auto}button{background:#276dc6;color:white;border:0;padding:7px 10px;border-radius:6px;cursor:pointer;margin:2px}code{color:#93c5fd}</style></head><body><main>
        <nav><a href="/">← CalebSec dashboard</a><a href="/network-ops">All</a><a href="/network-ops?source=suricata">Suricata</a><a href="/network-ops?source=zeek">Zeek</a></nav><h1>Network Security & SOAR</h1><p>Suricata alerts • Zeek network telemetry • Correlation • Audited playbook triage</p>"""+ ('<p>'+escape(notice[:120])+'</p>' if notice else '')+"""
        <section><h2>Recent sensor events</h2><table><thead><tr><th>ID</th><th>Source</th><th>Type</th><th>Time</th><th>Source IP</th><th>Dest IP</th><th>Summary</th><th>Investigation</th></tr></thead><tbody>"""+''.join(rows)+"""</tbody></table></section>
        <section><h2>SOAR playbook runs</h2><p>Automated triage creates/links an existing CalebSec case. Containment actions require separate approval and are not executed.</p><table><thead><tr><th>Time</th><th>Playbook</th><th>Status</th><th>Event ID</th></tr></thead><tbody>"""+runrows+"""</tbody></table></section></main></body></html>""")
    return router
