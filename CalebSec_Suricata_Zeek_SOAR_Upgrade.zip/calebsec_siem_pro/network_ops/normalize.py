"""Normalize Suricata EVE and Zeek JSON objects to CalebSec log model."""
from __future__ import annotations
from datetime import datetime, timezone
import hashlib
import ipaddress
import json


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def _stamp(raw):
    v = raw.get("timestamp") or raw.get("ts")
    if isinstance(v, (float, int)):
        return datetime.fromtimestamp(v, tz=timezone.utc).isoformat()
    if isinstance(v, str) and v:
        return v
    return utc_now()


def _ip(raw, *fields):
    for field in fields:
        x = raw.get(field)
        if x is not None and x != "":
            return str(x)
    return ""


def normalize(source, raw, zeek_log_type=None):
    if source not in {"suricata", "zeek"} or not isinstance(raw, dict):
        raise ValueError("source must be suricata/zeek and record must be an object")
    if len(json.dumps(raw)) > 65536:
        raise ValueError("individual sensor record exceeds 64 KiB")
    if source == "suricata":
        category = str(raw.get("event_type") or "unknown").lower()
        src = _ip(raw, "src_ip")
        dst = _ip(raw, "dest_ip")
        src_port = raw.get("src_port")
        dst_port = raw.get("dest_port")
        alert = raw.get("alert") if isinstance(raw.get("alert"), dict) else {}
        msg = alert.get("signature") or f"Suricata {category} event"
        dns = raw.get("dns") if isinstance(raw.get("dns"), dict) else {}
        http = raw.get("http") if isinstance(raw.get("http"), dict) else {}
        domain = dns.get("rrname") or http.get("hostname") or ""
        community_id = raw.get("community_id") or ""
        event_id = raw.get("flow_id")
        event_type = "suricata_" + category
    else:
        category = str(zeek_log_type or raw.get("_path") or raw.get("log_type") or "conn").lower().removesuffix(".log")
        src = _ip(raw, "id.orig_h", "src_ip")
        dst = _ip(raw, "id.resp_h", "dest_ip")
        src_port = raw.get("id.orig_p") or raw.get("src_port")
        dst_port = raw.get("id.resp_p") or raw.get("dest_port")
        domain = raw.get("query") or raw.get("host") or raw.get("server_name") or ""
        community_id = raw.get("community_id") or ""
        event_id = raw.get("uid")
        msg = f"Zeek {category} {src or '?'} -> {dst or '?'}"
        event_type = "zeek_" + category
    record = {
        "source": source,
        "category": category,
        "timestamp": _stamp(raw),
        "event_type": event_type,
        "username": "",
        "src_ip": src,
        "dest_ip": dst,
        "src_port": src_port,
        "dest_port": dst_port,
        "dest_domain": str(domain),
        "community_id": str(community_id),
        "sensor_uid": str(event_id or ""),
        "message": str(msg)[:2048],
        "raw": raw,
    }
    # Deterministic hash allows safe replay without duplicate stored records.
    canonical = json.dumps({"source": source, "log_type": category, "raw": raw}, sort_keys=True, separators=(",", ":"))
    record["event_hash"] = hashlib.sha256(canonical.encode()).hexdigest()
    return record


def suricata_alert(record):
    if record["source"] != "suricata" or record["category"] != "alert":
        return None
    data = record["raw"].get("alert")
    if not isinstance(data, dict):
        return None
    severity = data.get("severity", 3)
    try:
        numeric = int(severity)
    except (ValueError, TypeError):
        numeric = 3
    level = "Critical" if numeric == 1 else "High" if numeric == 2 else "Medium"
    signature = str(data.get("signature") or "Unknown Suricata signature")[:300]
    sig_id = str(data.get("signature_id") or "n/a")
    rule = f"Suricata SID {sig_id}: {signature}"
    description = f"Suricata IDS: {signature} ({record['src_ip'] or 'unknown'} -> {record['dest_ip'] or 'unknown'})"
    return {"rule": rule, "severity": level, "src_ip": record["src_ip"] or "unknown", "description": description, "mitre": "T1046 - Network Service Discovery" if "scan" in signature.lower() else "T1071 - Application Layer Protocol", "tactic": "Network Detection", "risk_score": 95 if level == "Critical" else 75 if level == "High" else 50}


def valid_public_ip(value):
    try:
        return ipaddress.ip_address(value).is_global
    except ValueError:
        return False
