"""Safe, auditable SOAR triage: enrichment/case creation, never network blocking."""
import json
from pathlib import Path
import os
import database
from . import store
from .normalize import suricata_alert, valid_public_ip

PLAYBOOK = "suricata_high_severity_triage"


def _ioc_enrich(ip):
    # Optional local IOC list; no network calls, no leaking IPs to external services.
    paths=[Path(__file__).resolve().parents[1]/"threat_intel"/"iocs.json",Path.cwd()/"threat_intel"/"iocs.json"]
    for p in paths:
        if p.is_file():
            try:
                data=json.loads(p.read_text())
                return {"ip":ip, "public_ip":valid_public_ip(ip), "local_ioc_match":ip in data.get("malicious_ips",[])}
            except (OSError,ValueError,TypeError):
                break
    return {"ip":ip, "public_ip":valid_public_ip(ip), "local_ioc_match":False}


def _lookup_alert(alert):
    with database.connect() as db:
        row=db.execute("SELECT id FROM alerts WHERE rule=? AND src_ip=? AND description=? ORDER BY id DESC LIMIT 1",(alert["rule"],alert["src_ip"],alert["description"])).fetchone()
        return row[0] if row else None


def run(event_id, dry_run=False, actor="network_ops"):
    event=store.get_event(event_id)
    if not event:
        raise ValueError("Unknown event")
    raw=json.loads(event["raw_json"])
    record={**event,"raw":raw}
    # Key translation for reusable normalizer function.
    record["dest_ip"]=event["dest_ip"]
    alert=suricata_alert(record)
    if not alert or alert["severity"] not in ("High","Critical"):
        raise ValueError("Playbook supports only high/critical Suricata alert events")
    prior=[r for r in store.list_runs(10000) if r["event_id"]==event_id and r["playbook"]==PLAYBOOK and bool(r["dry_run"])==dry_run]
    if prior:
        return {"status":"already_executed","run_id":prior[0]["id"],"result":json.loads(prior[0]["result_json"])}
    enrichment=_ioc_enrich(event["src_ip"])
    linked=store.related_events(event_id)
    result={"alert_rule":alert["rule"],"severity":alert["severity"],"enrichment":enrichment,
            "correlated_zeek_events":len([x for x in linked if x["source"]=="zeek"]),
            "recommended_action":"Review source IP; validate with asset owner before containment",
            "containment_executed":False,"case_id":None,"alert_id":None}
    if not dry_run:
        alert_id=_lookup_alert(alert)
        if alert_id is None:
            database.insert_alert(alert)
            alert_id=_lookup_alert(alert)
        result["alert_id"]=alert_id
        if alert_id is not None:
            with database.connect() as db:
                row=db.execute("SELECT id FROM cases WHERE alert_id=? ORDER BY id LIMIT 1",(alert_id,)).fetchone()
            if row:
                result["case_id"]=row[0]
            else:
                database.create_case(alert_id,"SOAR triage: "+alert["rule"][:160],
                    "Automated triage, no containment executed. Source IP: "+event["src_ip"]+
                    ". Correlated Zeek records: "+str(result["correlated_zeek_events"])+
                    ". Local IOC hit: "+str(enrichment["local_ioc_match"]))
                with database.connect() as db:
                    row=db.execute("SELECT id FROM cases WHERE alert_id=? ORDER BY id DESC LIMIT 1",(alert_id,)).fetchone()
                    result["case_id"]=row[0] if row else None
    status="preview" if dry_run else "completed"
    created=store.save_run(event_id,PLAYBOOK,status,dry_run,result)
    if created and not dry_run:
        database.log_audit_event(actor,"network_soar_triage",f"event={event_id}, alert={result['alert_id']}, case={result['case_id']}")
    return {"status":status if created else "already_executed","result":result}
