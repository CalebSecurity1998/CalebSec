"""Persistent extension state; existing SIEM tables remain authoritative."""
import json
import sqlite3
from datetime import datetime, timezone, timedelta
import database


def connect():
    db = database.connect()
    db.row_factory = sqlite3.Row
    return db


def init_tables():
    with connect() as db:
        db.execute("""CREATE TABLE IF NOT EXISTS network_sensor_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT, event_hash TEXT NOT NULL UNIQUE,
            source TEXT NOT NULL, category TEXT NOT NULL, timestamp TEXT,
            src_ip TEXT, dest_ip TEXT, src_port TEXT, dest_port TEXT,
            community_id TEXT, sensor_uid TEXT, domain TEXT, message TEXT,
            raw_json TEXT NOT NULL, received_at TEXT NOT NULL)""")
        db.execute("CREATE INDEX IF NOT EXISTS idx_net_src ON network_sensor_events(src_ip)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_net_dest ON network_sensor_events(dest_ip)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_net_community ON network_sensor_events(community_id)")
        db.execute("""CREATE TABLE IF NOT EXISTS network_soar_runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT, event_id INTEGER NOT NULL,
            playbook TEXT NOT NULL, status TEXT NOT NULL, dry_run INTEGER NOT NULL,
            result_json TEXT NOT NULL, created_at TEXT NOT NULL,
            UNIQUE(event_id, playbook, dry_run))""")


def insert_event(record):
    init_tables()
    with connect() as db:
        before = db.total_changes
        db.execute("""INSERT OR IGNORE INTO network_sensor_events
            (event_hash,source,category,timestamp,src_ip,dest_ip,src_port,dest_port,
             community_id,sensor_uid,domain,message,raw_json,received_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (
            record["event_hash"],record["source"],record["category"],record["timestamp"],
            record["src_ip"],record["dest_ip"],str(record["src_port"] or ""),
            str(record["dest_port"] or ""),record["community_id"],record["sensor_uid"],
            record["dest_domain"],record["message"],json.dumps(record["raw"]),
            datetime.now(timezone.utc).isoformat()))
        created = db.total_changes > before
        row = db.execute("SELECT id FROM network_sensor_events WHERE event_hash=?",(record["event_hash"],)).fetchone()
        return row["id"], created


def get_event(event_id):
    init_tables()
    with connect() as db:
        row=db.execute("SELECT * FROM network_sensor_events WHERE id=?",(event_id,)).fetchone()
        return dict(row) if row else None


def list_events(limit=100,source=None):
    init_tables()
    with connect() as db:
        if source in {"suricata","zeek"}:
            rows=db.execute("SELECT * FROM network_sensor_events WHERE source=? ORDER BY id DESC LIMIT ?",(source,limit)).fetchall()
        else:
            rows=db.execute("SELECT * FROM network_sensor_events ORDER BY id DESC LIMIT ?",(limit,)).fetchall()
        return [dict(r) for r in rows]


def list_runs(limit=100):
    init_tables()
    with connect() as db:
        return [dict(r) for r in db.execute("SELECT * FROM network_soar_runs ORDER BY id DESC LIMIT ?",(limit,)).fetchall()]


def save_run(event_id, playbook, status, dry_run, result):
    init_tables()
    with connect() as db:
        before=db.total_changes
        db.execute("""INSERT OR IGNORE INTO network_soar_runs
            (event_id,playbook,status,dry_run,result_json,created_at) VALUES(?,?,?,?,?,?)""",
            (event_id,playbook,status,int(dry_run),json.dumps(result),datetime.now(timezone.utc).isoformat()))
        return db.total_changes > before


def _dt(value):
    if not value:
        return None
    try:
        v=datetime.fromisoformat(str(value).replace("Z","+00:00"))
        return v if v.tzinfo else v.replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def related_events(event_id, minutes=10, limit=100):
    """Best-effort cross-sensor correlation; works even without community_id."""
    base=get_event(event_id)
    if not base:
        return []
    target=_dt(base["timestamp"])
    if target is None:
        return []
    init_tables()
    with connect() as db:
        rows=db.execute("SELECT * FROM network_sensor_events WHERE source != ? ORDER BY id DESC LIMIT 5000",(base["source"],)).fetchall()
    out=[]
    for item in rows:
        candidate=dict(item)
        seen=_dt(candidate["timestamp"])
        if seen is None or abs((seen-target).total_seconds())>minutes*60:
            continue
        community_match=bool(base["community_id"] and base["community_id"]==candidate["community_id"])
        endpoints=bool(base["src_ip"] and base["dest_ip"] and (
            (base["src_ip"],base["dest_ip"])==(candidate["src_ip"],candidate["dest_ip"]) or
            (base["src_ip"],base["dest_ip"])==(candidate["dest_ip"],candidate["src_ip"])))
        ports=not(base["src_port"] and base["dest_port"] and candidate["src_port"] and candidate["dest_port"]) or (
            (base["src_port"],base["dest_port"])==(candidate["src_port"],candidate["dest_port"]) or
            (base["src_port"],base["dest_port"])==(candidate["dest_port"],candidate["src_port"]))
        if community_match or (endpoints and ports):
            candidate.pop("raw_json",None)
            candidate["correlation_reason"]="community_id" if community_match else "endpoint/time"
            out.append(candidate)
        if len(out)>=limit:
            break
    return out
